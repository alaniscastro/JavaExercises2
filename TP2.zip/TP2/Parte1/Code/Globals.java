package Code;

public class Globals {
	/** 
	 * Atributos
	 */
	public static final int INICIAR_CIDADE = 0; // = 1
}
package p1;
import java.util.Vector;
import java.util.Collections;
public class Teste 
{
    private static final int MAX = 9000; //varia de aordo com o tamanho da árvore que vamos montar
    public static void main (String [] args)
    {
        ArvoreBinaria arvore = new ArvoreBinaria ();
        Item x;
        Vector<Integer> vetor = new Vector<>();
            
        for (int i = 0; i < MAX; i++)
            vetor.add(i);
        
        Collections.shuffle(vetor); //Usada apenas para inserção de elementos desordenados
        for (Integer i = 0; i < MAX; i++) 
        { 
            x = new Item (vetor.get(i));
            arvore.insere (x);
        }
        
        Item teste = new Item (9000);
        teste = (Item)arvore.pesquisa (teste, 0);
    }
}

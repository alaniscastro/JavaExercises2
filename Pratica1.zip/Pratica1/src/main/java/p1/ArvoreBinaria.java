package p1;
public class ArvoreBinaria 
{
    private static class No
    { 
        Item reg; 
        No esq, dir; 
    }
  
    private No raiz;
        
    private Item pesquisa (Item reg, No p, int n) //pesquisa por um item na arvore a partir do metodo compara da classe Item, olhando se o que procuramos é maior ou menor que o nó analisado e chamando recursivamente o método
    {
        if (p == null) 
        {
            System.out.println ("Comparações: "+ n);
            return null;
        }
        else 
        {
            if (reg.compara (p.reg) < 0)
            { 
                n++;
                return pesquisa (reg, p.esq, n);
            }
            else if (reg.compara (p.reg) > 0) 
            {
                n++;
                return pesquisa (reg, p.dir, n);
            }
        }
        return p.reg;
    }
  
    private No insere (Item reg, No p) //insere um item na árvore a partir do metodo compara da classe Item, olhando se o que queremos inserir é maior ou menor que o nó analisado e chamando recursivamente o método
    {
        if (p == null) 
        {
            p = new No (); p.reg = reg; 
            p.esq = null; p.dir = null;
        }
        else if (reg.compara (p.reg) < 0) p.esq = insere (reg, p.esq);
        else if (reg.compara (p.reg) > 0) p.dir = insere (reg, p.dir);
        else 
            System.out.println ("Erro: Registro ja existente");
        return p; 
    }

    public ArvoreBinaria () 
    {
        this.raiz = null;
    }
  
    public Item pesquisa (Item reg, int n) 
    {
        return this.pesquisa (reg, this.raiz, n);
    }

    public void insere (Item reg)   
    {
        this.raiz = this.insere (reg, this.raiz);
    }
}
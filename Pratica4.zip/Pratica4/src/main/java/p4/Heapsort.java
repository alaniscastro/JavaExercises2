package p4;

public class Heapsort 
{
    private Item vetorOrdenado[];
    private Heap heap;    
    
    public Heapsort() { }
    
    public Item[] ordenacao(Item v[]) //ordena o vetor chamando o construtor do heap
    {
        heap = new Heap(v);
        heap.constroi();
        vetorOrdenado = heap.getHeap();
        return this.vetorOrdenado;
    }
    
    public int comparacoes() 
    {
        return this.heap.comparacoes();
    }
}

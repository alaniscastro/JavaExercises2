/* Nomes: Alanis Viana, Luisa Oliveira e Matheus Freire
 * Laboratorio de Algoritmos e Estrutura de Dados 2
 */

package Item;

public class Localizacao {
    // cursor para pegar posicao da palavra no texto
    public static int linha;
    public static int coluna; // cada palavra fica em uma coluna
}